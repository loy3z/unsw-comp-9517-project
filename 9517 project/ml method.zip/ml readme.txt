Machine Learning Method - Random Forest Segmentation

1. Overview
This part implements the machine learning-based wheat crop segmentation method for the EWS dataset.
The task is formulated as pixel-wise binary classification.

Main pipeline:
- Load RGB images and corresponding masks
- Convert grayscale masks into binary labels
- Extract handcrafted features for each pixel
- Train a Random Forest classifier
- Predict pixel labels for validation/test images
- Apply morphological postprocessing
- Evaluate the predicted masks using Precision, Recall, F1-score, and IoU

2. Features
For each pixel, a 7-dimensional feature vector is extracted:
- RGB channels
- HSV channels
- Excess Green (ExG)

ExG is computed as:
ExG = 2G - R - B

3. Model Configuration
Classifier:
- Random Forest (scikit-learn)

Best hyperparameters:
- n_estimators = 100
- max_depth = 10
- random_state = 42

The final model is selected using validation IoU.

4. Dataset Structure
The code assumes the EWS dataset is organised as:

EWS-Dataset/
    train/
    validation/
    test/

In each split folder:
- RGB images are stored as .png files
- Ground-truth masks use the same filename with suffix "_mask.png"

5. Environment
Recommended environment:
- Python 3.x
- Jupyter Notebook or Python script

Required packages:
- os
- glob
- numpy
- cv2 (OpenCV)
- matplotlib
- scikit-learn

Example installation:
pip install numpy opencv-python matplotlib scikit-learn

6. How to Run
1. Set the dataset path in the code:
   base_dir = "path_to_EWS-Dataset"

2. Run the notebook/script in order:
   - data loading
   - mask preprocessing
   - feature extraction
   - training data construction
   - Random Forest training
   - validation evaluation and hyperparameter tuning
   - final test evaluation
   - success/failure case analysis

3. The code will output:
   - validation metrics
   - test metrics
   - saved prediction masks
   - saved success/failure case figures

7. Output
The method produces:
- Validation prediction masks
- Test prediction masks
- Quantitative metrics:
  - Precision
  - Recall
  - F1-score
  - IoU
- Example success/failure case images

8. Notes
- Crop pixels are labeled as 1, background pixels as 0
- Final prediction masks are binary masks
- Validation set is used for model selection
- Test set is used only for final evaluation
- To avoid large zip files, trained models, input images, and result images should not be included in the final code submission zip

9. Final Results
Best validation results:
- Precision = 0.7703
- Recall = 0.8186
- F1 = 0.7836
- IoU = 0.6585

Final test results:
- Precision = 0.7839
- Recall = 0.8261
- F1 = 0.7926
- IoU = 0.6737