from pathlib import Path

DATASET_ROOT = Path("../EWS-Dataset")

# Split folder names
TRAIN_SPLIT = "train"
VAL_SPLIT = "validation"
TEST_SPLIT = "test"

# Image settings
ORIGINAL_IMAGE_SIZE = (350, 350) # width, height
MASK_THRESHOLD = 128 # mask < 128 means plant = 1
FOREGROUND_VALUE = 255 # saved prediction mask foreground
BACKGROUND_VALUE = 0

# Output folders
OUTPUT_ROOT = Path("./outputs/traditional")
VAL_OUTPUT_DIR = OUTPUT_ROOT / "val_predictions"
TEST_OUTPUT_DIR = OUTPUT_ROOT / "test_predictions"
VIS_OUTPUT_DIR = OUTPUT_ROOT / "visualizations"
LOG_DIR = OUTPUT_ROOT / "logs"

# Supported image extensions
IMAGE_EXTENSIONS = [".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff"]