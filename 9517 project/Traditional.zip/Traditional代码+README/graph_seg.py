import time
from typing import Dict, Any, Tuple

import cv2
import numpy as np
from skimage.segmentation import felzenszwalb

from preprocess import preprocess_image, refine_binary_mask, remove_small_components
from utils import Timer

def segment_with_felzenszwalb(
    image_rgb: np.ndarray,
    scale: float = 100.0,
    sigma: float = 0.8,
    min_size: int = 50
) -> np.ndarray:
    """
    Run Felzenszwalb graph-based segmentation.

    Returns:
        segment_labels: (H, W) integer label map
    """
    segment_labels = felzenszwalb(
        image_rgb,
        scale=scale,
        sigma=sigma,
        min_size=min_size
    )
    return segment_labels

def build_region_mask_from_green_prior(
    segment_labels: np.ndarray,
    green_mask: np.ndarray,
    green_ratio_threshold: float = 0.3
) -> np.ndarray:
    """
    Select graph segments whose overlap with green prior is high enough.

    For each segment:
        green_ratio = (# green pixels in segment) / (segment size)

    If green_ratio >= threshold, mark the whole segment as plant.
    """
    green_mask = (green_mask > 0).astype(np.uint8)
    pred_mask = np.zeros_like(green_mask, dtype=np.uint8)

    unique_labels = np.unique(segment_labels)

    for label_id in unique_labels:
        region = (segment_labels == label_id)
        region_size = np.sum(region)

        if region_size == 0:
            continue

        green_pixels = np.sum(green_mask[region])
        green_ratio = green_pixels / (region_size + 1e-8)

        if green_ratio >= green_ratio_threshold:
            pred_mask[region] = 1

    return pred_mask

def run_graph_segmentation(
    image_rgb: np.ndarray,
    use_clahe: bool = False,
    blur_kernel: int = 5,
    lower_hsv: Tuple[int, int, int] = (25, 30, 20),
    upper_hsv: Tuple[int, int, int] = (95, 255, 255),
    refine_green_mask_flag: bool = True,
    min_component_area: int = 50,
    graph_scale: float = 100.0,
    graph_sigma: float = 0.8,
    graph_min_size: int = 50,
    green_ratio_threshold: float = 0.3,
    post_open_kernel: int = 3,
    post_close_kernel: int = 5,
    post_remove_small_area: int = 50
) -> Dict[str, Any]:
    """
    Run graph-based segmentation with green-prior guided region selection.

    Returns:
        {
            "pred_mask": ...,
            "runtime": ...,
            "green_mask": ...,
            "segment_labels": ...,
            "raw_region_mask": ...
        }
    """
    timer = Timer()
    timer.start()

    # Step 1: preprocessing
    prep = preprocess_image(
        image_rgb=image_rgb,
        use_clahe=use_clahe,
        blur_kernel=blur_kernel,
        lower_hsv=lower_hsv,
        upper_hsv=upper_hsv,
        refine_green_mask=refine_green_mask_flag,
        min_component_area=min_component_area
    )

    blurred_rgb = prep["blurred_rgb"]
    green_mask = prep["green_mask"]

    # Step 2: graph-based segmentation
    segment_labels = segment_with_felzenszwalb(
        image_rgb=blurred_rgb,
        scale=graph_scale,
        sigma=graph_sigma,
        min_size=graph_min_size
    )

    # Step 3: select plant-like regions based on green prior
    raw_region_mask = build_region_mask_from_green_prior(
        segment_labels=segment_labels,
        green_mask=green_mask,
        green_ratio_threshold=green_ratio_threshold
    )

    pred_mask = raw_region_mask.copy()

    # Step 4: postprocessing
    if post_open_kernel > 0 or post_close_kernel > 0:
        open_k = max(1, post_open_kernel)
        close_k = max(1, post_close_kernel)
        pred_mask = refine_binary_mask(
            pred_mask,
            open_kernel=open_k,
            close_kernel=close_k
        )

    if post_remove_small_area > 0:
        pred_mask = remove_small_components(
            pred_mask,
            min_area=post_remove_small_area
        )

    runtime = timer.stop()

    return {
        "pred_mask": pred_mask,
        "runtime": runtime,
        "green_mask": green_mask,
        "segment_labels": segment_labels,
        "raw_region_mask": raw_region_mask,
    }

def get_default_graph_params() -> Dict[str, Any]:
    """
    Default parameter set for graph-based segmentation.
    """
    return {
        "use_clahe": False,
        "blur_kernel": 5,
        "lower_hsv": (25, 30, 20),
        "upper_hsv": (95, 255, 255),
        "refine_green_mask_flag": True,
        "min_component_area": 50,
        "graph_scale": 100.0,
        "graph_sigma": 0.8,
        "graph_min_size": 50,
        "green_ratio_threshold": 0.3,
        "post_open_kernel": 3,
        "post_close_kernel": 5,
        "post_remove_small_area": 50,
    }