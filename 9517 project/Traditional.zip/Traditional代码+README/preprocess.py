import cv2
import numpy as np
from typing import Dict, Tuple


def rgb_to_hsv(image_rgb: np.ndarray) -> np.ndarray:
    """
    Convert RGB image to HSV.
    OpenCV expects uint8 input and uses H in [0,179].
    """
    if image_rgb.dtype != np.uint8:
        image_rgb = image_rgb.astype(np.uint8)
    hsv = cv2.cvtColor(image_rgb, cv2.COLOR_RGB2HSV)
    return hsv

def apply_gaussian_blur(image_rgb: np.ndarray, kernel_size: int = 5) -> np.ndarray:
    """
    Apply Gaussian blur to reduce small noise.
    kernel_size must be odd.
    """
    if kernel_size % 2 == 0:
        raise ValueError("kernel_size must be odd.")
    blurred = cv2.GaussianBlur(image_rgb, (kernel_size, kernel_size), 0)
    return blurred

def enhance_contrast_clahe(image_rgb: np.ndarray, clip_limit: float = 2.0, tile_grid_size: int = 8) -> np.ndarray:
    """
    Enhance local contrast using CLAHE on the L channel in LAB color space.
    This is optional but often helpful under uneven lighting.
    """
    lab = cv2.cvtColor(image_rgb, cv2.COLOR_RGB2LAB)
    l, a, b = cv2.split(lab)

    clahe = cv2.createCLAHE(
        clipLimit=clip_limit,
        tileGridSize=(tile_grid_size, tile_grid_size)
    )
    l_enhanced = clahe.apply(l)

    lab_enhanced = cv2.merge([l_enhanced, a, b])
    image_enhanced = cv2.cvtColor(lab_enhanced, cv2.COLOR_LAB2RGB)
    return image_enhanced

def get_green_mask_hsv(
    image_rgb: np.ndarray,
    lower_hsv: Tuple[int, int, int] = (25, 30, 20),
    upper_hsv: Tuple[int, int, int] = (95, 255, 255)
) -> np.ndarray:
    """
    Extract a rough green-region prior in HSV space.
    Output: binary mask in {0,1}
    """
    hsv = rgb_to_hsv(image_rgb)
    lower = np.array(lower_hsv, dtype=np.uint8)
    upper = np.array(upper_hsv, dtype=np.uint8)

    green_mask = cv2.inRange(hsv, lower, upper)
    green_mask = (green_mask > 0).astype(np.uint8)
    return green_mask

def refine_binary_mask(
    mask_binary: np.ndarray,
    open_kernel: int = 3,
    close_kernel: int = 5
) -> np.ndarray:
    """
    Refine a binary mask using morphological opening and closing.
    Output stays in {0,1}.
    """
    mask = (mask_binary > 0).astype(np.uint8) * 255

    open_k = np.ones((open_kernel, open_kernel), np.uint8)
    close_k = np.ones((close_kernel, close_kernel), np.uint8)

    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, open_k)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, close_k)

    return (mask > 0).astype(np.uint8)

def remove_small_components(mask_binary: np.ndarray, min_area: int = 50) -> np.ndarray:
    """
    Remove very small connected components from a binary mask.
    Useful for suppressing isolated false positives.
    """
    mask = (mask_binary > 0).astype(np.uint8)
    num_labels, labels, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)

    cleaned = np.zeros_like(mask, dtype=np.uint8)

    for label_id in range(1, num_labels):  # skip background
        area = stats[label_id, cv2.CC_STAT_AREA]
        if area >= min_area:
            cleaned[labels == label_id] = 1

    return cleaned

def preprocess_image(
    image_rgb: np.ndarray,
    use_clahe: bool = False,
    blur_kernel: int = 5,
    lower_hsv: Tuple[int, int, int] = (25, 30, 20),
    upper_hsv: Tuple[int, int, int] = (95, 255, 255),
    refine_green_mask: bool = True,
    min_component_area: int = 50
) -> Dict[str, np.ndarray]:
    """
    Unified preprocessing pipeline for traditional segmentation methods.

    Returns a dictionary containing:
    - original_rgb
    - blurred_rgb
    - enhanced_rgb
    - hsv
    - green_mask
    """
    original_rgb = image_rgb.copy()

    if use_clahe:
        enhanced_rgb = enhance_contrast_clahe(original_rgb)
    else:
        enhanced_rgb = original_rgb.copy()

    blurred_rgb = apply_gaussian_blur(enhanced_rgb, kernel_size=blur_kernel)
    hsv = rgb_to_hsv(blurred_rgb)

    green_mask = get_green_mask_hsv(
        blurred_rgb,
        lower_hsv=lower_hsv,
        upper_hsv=upper_hsv
    )

    if refine_green_mask:
        green_mask = refine_binary_mask(green_mask, open_kernel=3, close_kernel=5)
        green_mask = remove_small_components(green_mask, min_area=min_component_area)

    return {
        "original_rgb": original_rgb,
        "enhanced_rgb": enhanced_rgb,
        "blurred_rgb": blurred_rgb,
        "hsv": hsv,
        "green_mask": green_mask,
    }