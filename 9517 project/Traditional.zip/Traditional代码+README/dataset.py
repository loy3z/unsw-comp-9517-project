from pathlib import Path
from typing import List, Tuple, Dict
import cv2
import numpy as np
from PIL import Image

from config import (
    DATASET_ROOT,
    TRAIN_SPLIT,
    VAL_SPLIT,
    TEST_SPLIT,
    IMAGE_EXTENSIONS,
    ORIGINAL_IMAGE_SIZE,
    MASK_THRESHOLD,
)

SampleInfo = Dict[str, Path]

def get_split_dir(split: str) -> Path:
    """
    Return the directory of a given split.
    Must match the same split naming used by the deep learning code.
    """
    split = split.lower()
    if split == "train":
        return DATASET_ROOT / TRAIN_SPLIT
    elif split in ["val", "validation", "valid"]:
        return DATASET_ROOT / VAL_SPLIT
    elif split == "test":
        return DATASET_ROOT / TEST_SPLIT
    else:
        raise ValueError(f"Unknown split: {split}")

def list_image_files(split_dir: Path) -> List[Path]:
    """
    List all image files in a split folder, excluding mask files.
    """
    image_files = []
    for ext in IMAGE_EXTENSIONS:
        image_files.extend(split_dir.glob(f"*{ext}"))
        image_files.extend(split_dir.glob(f"*{ext.upper()}"))

    image_files = sorted([p for p in image_files if "_mask" not in p.name])
    return image_files

def get_mask_path(image_path: Path) -> Path:
    """
    Match mask path using the same naming rule as the deep learning code:
        image: xxx.png
        mask : xxx_mask.png
    """
    return image_path.parent / image_path.name.replace(".png", "_mask.png")

def get_pairs(split: str) -> List[Tuple[Path, Path]]:
    """
    Return a list of (image_path, mask_path) pairs for one split.
    """
    split_dir = get_split_dir(split)
    if not split_dir.exists():
        raise FileNotFoundError(f"Split directory not found: {split_dir}")

    image_files = list_image_files(split_dir)
    if len(image_files) == 0:
        raise RuntimeError(f"No image files found in {split_dir}")

    pairs = []
    for img_path in image_files:
        mask_path = get_mask_path(img_path)
        if not mask_path.exists():
            raise FileNotFoundError(f"Missing mask for image: {img_path.name}")
        pairs.append((img_path, mask_path))

    return pairs

def read_image_rgb(image_path: Path) -> np.ndarray:
    """
    Read image as RGB uint8 array of shape (H, W, 3).
    """
    image = np.array(Image.open(image_path).convert("RGB"))

    # Safety check: make sure size is correct
    if (image.shape[1], image.shape[0]) != ORIGINAL_IMAGE_SIZE:
        image = cv2.resize(image, ORIGINAL_IMAGE_SIZE, interpolation=cv2.INTER_LINEAR)

    return image.astype(np.uint8)

def read_mask_binary(mask_path: Path) -> np.ndarray:
    """
    Read ground-truth mask exactly following the deep learning teammate's convention:
    1) if mask has multiple channels, use channel 0
    2) dark pixels (value < 128) are plant = 1
    3) return binary mask in {0, 1}
    """
    mask_array = np.array(Image.open(mask_path))

    if mask_array.ndim == 3:
        mask_raw = mask_array[:, :, 0]
    else:
        mask_raw = mask_array

    if (mask_raw.shape[1], mask_raw.shape[0]) != ORIGINAL_IMAGE_SIZE:
        mask_raw = cv2.resize(mask_raw, ORIGINAL_IMAGE_SIZE, interpolation=cv2.INTER_NEAREST)

    mask_binary = (mask_raw < MASK_THRESHOLD).astype(np.uint8)
    return mask_binary

def load_sample(pair: Tuple[Path, Path]) -> Dict[str, np.ndarray]:
    """
    Load one sample and return a standard dictionary.
    """
    image_path, mask_path = pair
    image = read_image_rgb(image_path)
    mask = read_mask_binary(mask_path)

    return {
        "name": image_path.name,
        "image_path": image_path,
        "mask_path": mask_path,
        "image": image,
        "mask": mask,
    }

def load_split(split: str) -> List[Dict[str, np.ndarray]]:
    """
    Load all samples from one split.
    """
    pairs = get_pairs(split)
    return [load_sample(pair) for pair in pairs]