import json
import time
from pathlib import Path
from typing import Dict, Any

import cv2
import numpy as np
import matplotlib.pyplot as plt

from config import FOREGROUND_VALUE, BACKGROUND_VALUE

def ensure_dir(path: Path) -> None:
    """
    Create directory if it does not exist.
    """
    path.mkdir(parents=True, exist_ok=True)

# Mask Conversion & Saving
def binary_to_uint8(mask_binary: np.ndarray) -> np.ndarray:
    """
    Convert binary mask {0,1} → {0,255}
    """
    mask_binary = (mask_binary > 0).astype(np.uint8)
    return np.where(mask_binary == 1, FOREGROUND_VALUE, BACKGROUND_VALUE).astype(np.uint8)

def save_prediction_mask(mask_binary: np.ndarray, save_path: Path) -> None:
    """
    Save prediction mask as PNG (0/255).
    """
    save_path.parent.mkdir(parents=True, exist_ok=True)
    mask_uint8 = binary_to_uint8(mask_binary)
    cv2.imwrite(str(save_path), mask_uint8)

# Evaluation Metrics
def compute_confusion(pred: np.ndarray, gt: np.ndarray):
    """
    Compute TP, FP, FN, TN for binary segmentation.
    """
    pred = (pred > 0).astype(np.uint8)
    gt = (gt > 0).astype(np.uint8)

    tp = np.sum((pred == 1) & (gt == 1))
    fp = np.sum((pred == 1) & (gt == 0))
    fn = np.sum((pred == 0) & (gt == 1))
    tn = np.sum((pred == 0) & (gt == 0))

    return tp, fp, fn, tn

def compute_metrics(pred: np.ndarray, gt: np.ndarray) -> Dict[str, float]:
    """
    Compute:
    - Precision
    - Recall
    - F1 score
    - IoU
    """
    tp, fp, fn, tn = compute_confusion(pred, gt)

    precision = tp / (tp + fp + 1e-8)
    recall = tp / (tp + fn + 1e-8)
    f1 = 2 * precision * recall / (precision + recall + 1e-8)
    iou = tp / (tp + fp + fn + 1e-8)

    return {
        "precision": float(precision),
        "recall": float(recall),
        "f1": float(f1),
        "iou": float(iou),
        "tp": int(tp),
        "fp": int(fp),
        "fn": int(fn),
        "tn": int(tn),
    }

# Timer (for testing time)
class Timer:
    """
    Simple timer for runtime measurement.
    Required for project report (testing time comparison).
    """

    def __init__(self):
        self.start_time = None

    def start(self):
        self.start_time = time.perf_counter()

    def stop(self) -> float:
        if self.start_time is None:
            raise RuntimeError("Timer not started.")
        elapsed = time.perf_counter() - self.start_time
        self.start_time = None
        return elapsed

# Logging
def save_json(data: Dict[str, Any], save_path: Path) -> None:
    """
    Save dictionary as JSON file (for parameters, results).
    """
    save_path.parent.mkdir(parents=True, exist_ok=True)
    with open(save_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

# Visualization (for report)
def overlay_mask(image_rgb: np.ndarray, mask_binary: np.ndarray, alpha: float = 0.35) -> np.ndarray:
    """
    Overlay predicted mask on image (red highlight).
    """
    image = image_rgb.copy()
    overlay = image.copy()

    mask = (mask_binary > 0)
    overlay[mask] = [255, 0, 0]  # red

    blended = (image * (1 - alpha) + overlay * alpha).astype(np.uint8)
    return blended

def save_visualization(
    image_rgb: np.ndarray,
    gt_mask: np.ndarray,
    pred_mask: np.ndarray,
    save_path: Path,
    title: str = ""
) -> None:
    """
    Save 4-panel visualization:
    Image / GT / Prediction / Overlay
    """
    save_path.parent.mkdir(parents=True, exist_ok=True)

    fig, axes = plt.subplots(1, 4, figsize=(16, 4))

    axes[0].imshow(image_rgb)
    axes[0].set_title("Image")
    axes[0].axis("off")

    axes[1].imshow(gt_mask, cmap="gray")
    axes[1].set_title("Ground Truth")
    axes[1].axis("off")

    axes[2].imshow(pred_mask, cmap="gray")
    axes[2].set_title("Prediction")
    axes[2].axis("off")

    axes[3].imshow(overlay_mask(image_rgb, pred_mask))
    axes[3].set_title("Overlay")
    axes[3].axis("off")

    if title:
        fig.suptitle(title)

    plt.tight_layout()
    plt.savefig(save_path, dpi=200, bbox_inches="tight")
    plt.close(fig)