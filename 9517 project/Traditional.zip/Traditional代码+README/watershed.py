import cv2
import numpy as np
from typing import Dict, Any, Tuple

from preprocess import preprocess_image
from utils import Timer

def build_markers_from_green_mask(
    green_mask: np.ndarray,
    sure_fg_erode_kernel: int = 5,
    sure_bg_dilate_kernel: int = 7,
    sure_fg_iterations: int = 1,
    sure_bg_iterations: int = 1
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Build watershed markers from a binary green mask.

    Returns:
        sure_fg: definite foreground mask {0,1}
        sure_bg: definite background mask {0,1}
        unknown: unknown region mask {0,1}
    """
    green_mask = (green_mask > 0).astype(np.uint8)

    fg_kernel = np.ones((sure_fg_erode_kernel, sure_fg_erode_kernel), np.uint8)
    bg_kernel = np.ones((sure_bg_dilate_kernel, sure_bg_dilate_kernel), np.uint8)

    # Sure foreground: erode the green mask
    sure_fg = cv2.erode(green_mask, fg_kernel, iterations=sure_fg_iterations)

    # Sure background: invert green mask, then dilate
    inv_mask = 1 - green_mask
    sure_bg = cv2.dilate(inv_mask, bg_kernel, iterations=sure_bg_iterations)

    # Unknown region: neither sure foreground nor sure background
    unknown = np.ones_like(green_mask, dtype=np.uint8)
    unknown[(sure_fg == 1) | (sure_bg == 1)] = 0

    return sure_fg, sure_bg, unknown

def create_watershed_markers(
    sure_fg: np.ndarray,
    sure_bg: np.ndarray,
    unknown: np.ndarray
) -> np.ndarray:
    """
    Create marker image for cv2.watershed.

    Marker convention for OpenCV watershed:
    - background > 0
    - foreground > 0
    - unknown = 0

    We use:
    - sure background -> 1
    - sure foreground -> 2
    - unknown -> 0
    """
    markers = np.zeros_like(sure_fg, dtype=np.int32)
    markers[sure_bg == 1] = 1
    markers[sure_fg == 1] = 2
    markers[unknown == 1] = 0
    return markers

def run_watershed_segmentation(
    image_rgb: np.ndarray,
    use_clahe: bool = False,
    blur_kernel: int = 5,
    lower_hsv: Tuple[int, int, int] = (25, 30, 20),
    upper_hsv: Tuple[int, int, int] = (95, 255, 255),
    refine_green_mask: bool = True,
    min_component_area: int = 50,
    sure_fg_erode_kernel: int = 5,
    sure_bg_dilate_kernel: int = 7,
    sure_fg_iterations: int = 1,
    sure_bg_iterations: int = 1,
    post_open_kernel: int = 3,
    post_close_kernel: int = 5
) -> Dict[str, Any]:
    """
    Run marker-based watershed segmentation for plant/soil separation.

    Returns a dictionary containing:
    - pred_mask: final predicted mask {0,1}, where 1 = plant
    - runtime: inference time in seconds
    - green_mask: preprocessed green prior
    - sure_fg
    - sure_bg
    - unknown
    - watershed_labels
    - markers_before
    """
    timer = Timer()
    timer.start()

    # Step 1: preprocessing
    prep = preprocess_image(
        image_rgb=image_rgb,
        use_clahe=use_clahe,
        blur_kernel=blur_kernel,
        lower_hsv=lower_hsv,
        upper_hsv=upper_hsv,
        refine_green_mask=refine_green_mask,
        min_component_area=min_component_area
    )

    blurred_rgb = prep["blurred_rgb"]
    green_mask = prep["green_mask"]

    # Step 2: build markers from green prior
    sure_fg, sure_bg, unknown = build_markers_from_green_mask(
        green_mask=green_mask,
        sure_fg_erode_kernel=sure_fg_erode_kernel,
        sure_bg_dilate_kernel=sure_bg_dilate_kernel,
        sure_fg_iterations=sure_fg_iterations,
        sure_bg_iterations=sure_bg_iterations
    )

    markers = create_watershed_markers(sure_fg, sure_bg, unknown)
    markers_before = markers.copy()

    # Step 3: run watershed
    # OpenCV watershed modifies marker array in-place
    image_bgr = cv2.cvtColor(blurred_rgb, cv2.COLOR_RGB2BGR)
    watershed_labels = cv2.watershed(image_bgr, markers)

    # Step 4: extract plant region
    # We defined sure foreground as label 2, so its grown region should remain 2
    pred_mask = (watershed_labels == 2).astype(np.uint8)

    # Step 5: postprocessing
    if post_open_kernel > 0:
        open_kernel = np.ones((post_open_kernel, post_open_kernel), np.uint8)
        pred_mask = cv2.morphologyEx(pred_mask * 255, cv2.MORPH_OPEN, open_kernel)
        pred_mask = (pred_mask > 0).astype(np.uint8)

    if post_close_kernel > 0:
        close_kernel = np.ones((post_close_kernel, post_close_kernel), np.uint8)
        pred_mask = cv2.morphologyEx(pred_mask * 255, cv2.MORPH_CLOSE, close_kernel)
        pred_mask = (pred_mask > 0).astype(np.uint8)

    runtime = timer.stop()

    return {
        "pred_mask": pred_mask,
        "runtime": runtime,
        "green_mask": green_mask,
        "sure_fg": sure_fg,
        "sure_bg": sure_bg,
        "unknown": unknown,
        "watershed_labels": watershed_labels,
        "markers_before": markers_before,
    }

def get_default_watershed_params() -> Dict[str, Any]:
    """
    Return a default parameter dictionary for watershed.
    Useful for validation tuning later.
    """
    return {
        "use_clahe": False,
        "blur_kernel": 5,
        "lower_hsv": (25, 30, 20),
        "upper_hsv": (95, 255, 255),
        "refine_green_mask": True,
        "min_component_area": 50,
        "sure_fg_erode_kernel": 5,
        "sure_bg_dilate_kernel": 7,
        "sure_fg_iterations": 1,
        "sure_bg_iterations": 1,
        "post_open_kernel": 3,
        "post_close_kernel": 5,
    }