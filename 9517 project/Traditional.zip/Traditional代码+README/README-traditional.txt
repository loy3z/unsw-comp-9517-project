Traditional Method：

Run instructions:
1. Install dependencies
2. Run run_watershed.py / run_graph_seg.py
3. Outputs will be saved in outputs/

Dataset:
EWS dataset